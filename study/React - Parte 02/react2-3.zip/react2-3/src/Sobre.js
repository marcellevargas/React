import React, { Fragment } from 'react';
import Header from './Header';

const Sobre = () => {

	return(
		<Fragment>
			<Header />
			<h1> Sobre </h1>
		</Fragment>
	);
}
export default Sobre;


